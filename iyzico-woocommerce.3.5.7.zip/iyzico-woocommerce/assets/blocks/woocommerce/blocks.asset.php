<?php return array('dependencies' => array('wp-html-entities'), 'version' => 'c0cacc6c3d04f2792f02');
