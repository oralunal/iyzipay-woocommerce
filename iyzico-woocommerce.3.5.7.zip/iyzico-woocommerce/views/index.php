<?php

printf(
	'<div class="wrap" id="iyzico-app">%s</div>',
	esc_html__( 'Loading…', 'iyzico' )
);