<?php return array('dependencies' => array('wp-html-entities'), 'version' => '969a4702d59d9e260099');
